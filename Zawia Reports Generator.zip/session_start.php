<?php
///////////////////////////////////////// This Code Created By Majdi Awad - Oct. 2019
if (session_status() == PHP_SESSION_NONE) {
    session_start([
        'cookie_lifetime' => 0,           
        'cookie_secure' => true,         
        'cookie_httponly' => true,        
        'use_strict_mode' => true,        
        'use_cookies' => true,            
        'use_only_cookies' => true,       
    ]);

    if (!isset($_SESSION['created'])) {
        $_SESSION['created'] = time();
    } else if (time() - $_SESSION['created'] > 1800) {
        session_regenerate_id(true);
        $_SESSION['created'] = time();
    }
}
?>
