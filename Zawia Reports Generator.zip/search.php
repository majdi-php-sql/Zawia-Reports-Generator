<?php
///////////////////////////////////////// This Code Created By Majdi Awad - Oct. 2019
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;

function getSheetData($filePath, $sheetName)
{
    $reader = new Xlsx();
    $spreadsheet = $reader->load($filePath);
    $sheet = $spreadsheet->getSheetByName($sheetName);
    if ($sheet === null) {
        return [];
    }

    $sheetData = $sheet->toArray(null, true, true, true);
    $headers = array_shift($sheetData); 

    $data = [];
    foreach ($sheetData as $row) {
        if (count($row) == count($headers)) {
            $data[] = array_combine($headers, $row);
        } else {
            error_log("Mismatched row: " . json_encode($row));
        }
    }
    return $data;
}

$salesData = getSheetData('data/zawia.xlsx', 'Sales');
$projectsData = getSheetData('data/zawia.xlsx', 'Projects');
$collectionData = getSheetData('data/zawia.xlsx', 'Collection');

$searchType = $_POST['searchType'] ?? '';
$searchQuery = $_POST['searchQuery'] ?? '';
$results = [];

switch ($searchType) {
    case 'sales_person':
        foreach ($salesData as $row) {
            if (stripos($row['Sales_Person'], $searchQuery) !== false) {
                $results[] = $row;
            }
        }
        break;
    case 'project_type':
        foreach ($salesData as $row) {
            if (stripos($row['Project_Type'], $searchQuery) !== false) {
                $results[] = $row;
            }
        }
        break;
    case 'emirate':
        foreach ($salesData as $row) {
            if (stripos($row['Emirate'], $searchQuery) !== false) {
                $results[] = $row;
            }
        }
        break;
    case 'project_id':
        foreach ($projectsData as $projectRow) {
            if ($projectRow['Project_id'] == $searchQuery) {
                $collectionRow = array_filter($collectionData, function($colRow) use ($searchQuery) {
                    return $colRow['Project_Id'] == $searchQuery;
                });
                $collectionRow = reset($collectionRow); 
                if ($collectionRow) {
                    $results[] = array_merge($projectRow, $collectionRow);
                } else {
                    $results[] = $projectRow;
                }
            }
        }
        break;
    case 'remaining':
        foreach ($collectionData as $row) {
            if (preg_match('/^([><]=?)\s*(\d+)$/', $searchQuery, $matches)) {
                $operator = $matches[1];
                $value = (float)$matches[2];
                if (eval("return (float)\$row['Remaining'] $operator $value;")) {
                    $results[] = $row;
                }
            }
        }
        break;
    default:
        echo "Invalid search type";
        exit();
}

if (empty($results)) {
    echo "<p>No results found.</p>";
} else {
    echo "<table border='1'><thead><tr>";
    foreach (array_keys($results[0]) as $header) {
        echo "<th>" . htmlspecialchars($header) . "</th>";
    }
    echo "</tr></thead><tbody>";
    foreach ($results as $result) {
        echo "<tr>";
        foreach ($result as $value) {
            echo "<td>" . htmlspecialchars($value) . "</td>";
        }
        echo "</tr>";
    }
    echo "</tbody></table>";
}
?>