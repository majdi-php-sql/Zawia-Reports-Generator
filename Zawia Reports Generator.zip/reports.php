<?php
///////////////////////////////////////// This Code Created By Majdi Awad - Oct. 2019
include 'session_start.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Search</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            width: 80%;
            margin: 0 auto;
        }
        h1 {
            text-align: center;
        }
        form {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }
        select, input, button {
            margin: 0 10px;
        }
        #results {
            margin-top: 20px;
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Search Reports</h1>
        <form id="searchForm">
            <label for="searchType">Search by:</label>
            <select id="searchType" name="searchType">
                <option value="sales_person">Sales Person</option>
                <option value="project_type">Project Type</option>
                <option value="emirate">Emirate</option>
                <option value="project_id">Project ID</option>
                <option value="remaining">Remaining Amount</option>
            </select>
            <input type="text" id="searchQuery" name="searchQuery">
            <button type="button" onclick="searchReports()">Search</button>
        </form>
        <div id="results"></div>
    </div>
    <script>
        function searchReports() {
            const searchType = document.getElementById('searchType').value;
            const searchQuery = document.getElementById('searchQuery').value;

            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'search.php', true);
            xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    document.getElementById('results').innerHTML = xhr.responseText;
                }
            };
            xhr.send(`searchType=${searchType}&searchQuery=${searchQuery}`);
        }
    </script>
</body>
</html>
