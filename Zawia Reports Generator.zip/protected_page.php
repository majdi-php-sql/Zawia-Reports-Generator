<?php
///////////////////////////////////////// This Code Created By Majdi Awad - Oct. 2019

include 'session_start.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Protected Page</title>
</head>
<body>
    <h1>Welcome to the protected page!</h1>
    <p>This content is only accessible to authenticated users.</p>
</body>
</html>
