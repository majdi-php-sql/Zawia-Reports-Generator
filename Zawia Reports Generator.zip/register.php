<?php
///////////////////////////////////////// This Code Created By Majdi Awad - Oct. 2019
include 'db_connect.php';
include 'csrf.php';

function generateSalt($length = 32) {
    return bin2hex(random_bytes($length));
}

function hashPassword($password, $salt) {
    return hash('sha256', $password . $salt);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!validateCSRFToken($_POST['csrf_token'])) {
        die('CSRF token validation failed');
    }

    $username = $_POST['username'];
    $password = $_POST['password'];
    $employee_id = $_POST['employee_id'];

    $salt = generateSalt();
    $password_hash = hashPassword($password, $salt);

    $stmt = $pdo->prepare('INSERT INTO users (username, password_hash, salt) VALUES (?, ?, ?)');
    $stmt->execute([$username, $password_hash, $salt]);

    $user_id = $pdo->lastInsertId();
    $stmt = $pdo->prepare('INSERT INTO employee_ids (user_id, employee_id) VALUES (?, ?)');
    $stmt->execute([$user_id, $employee_id]);

    echo "User registered successfully!";
}
?>

<form method="post" action="register.php">
    Username: <input type="text" name="username" required><br>
    Password: <input type="password" name="password" required><br>
    Employee ID: <input type="text" name="employee_id" required><br>
    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
    <input type="submit" value="Register">
</form>
