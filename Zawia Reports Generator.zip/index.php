<?php
///////////////////////////////////////// This Code Created By Majdi Awad - Oct. 2019
include 'db_connect.php';
include 'csrf.php';
include 'session_start.php';

function hashPassword($password, $salt) {
    return hash('sha256', $password . $salt);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!validateCSRFToken($_POST['csrf_token'])) {
        die('CSRF token validation failed');
    }

    $username = $_POST['username'];
    $password = $_POST['password'];
    $employee_id = $_POST['employee_id'];

    $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ?');
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user) {
        if ($user['account_locked']) {
            die('Account is locked due to multiple failed login attempts. Please contact support.');
        }

        if (hashPassword($password, $user['salt']) === $user['password_hash']) {
            $stmt = $pdo->prepare('SELECT * FROM employee_ids WHERE user_id = ? AND employee_id = ?');
            $stmt->execute([$user['id'], $employee_id]);
            $employee = $stmt->fetch();

            if ($employee) {
                $_SESSION['user_id'] = $user['id'];
                echo "Login successful!";
                $stmt = $pdo->prepare('UPDATE users SET failed_attempts = 0 WHERE id = ?');
                $stmt->execute([$user['id']]);
                header("Location: reports.php");
                exit();
            } else {
                echo "Invalid employee ID.";
            }
        } else {
            echo "Invalid username or password.";
            $stmt = $pdo->prepare('UPDATE users SET failed_attempts = failed_attempts + 1, last_failed_login = NOW() WHERE id = ?');
            $stmt->execute([$user['id']]);
            if ($user['failed_attempts'] + 1 >= 5) {
                $stmt = $pdo->prepare('UPDATE users SET account_locked = TRUE WHERE id = ?');
                $stmt->execute([$user['id']]);
            }
        }
    } else {
        echo "Invalid username or password.";
    }
}
?>

<form method="post" action="index.php">
    Username: <input type="text" name="username" required><br>
    Password: <input type="password" name="password" required><br>
    Employee ID: <input type="text" name="employee_id" required><br>
    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
    <input type="submit" value="Login">
</form>
